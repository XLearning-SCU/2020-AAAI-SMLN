import scipy.io as sio
import h5py
import os
import json

def load_deep_features(data_name, ratio=0.5):
    import numpy as np
    data_name_old = data_name
    valid_data, req_rec, b_wv_matrix = True, True, True
    few_labels, doc2vec = False, False
    if data_name.find('_few_labels') > -1:
        few_labels = True
        data_name = data_name.replace('_few_labels', '')
    if data_name.find('_doc2vec') > -1:
        doc2vec = True and not few_labels
        req_rec, b_wv_matrix = False, False
    if data_name == 'wiki_doc2vec':
        path = '../data/wiki_data/wiki_deep_doc2vec_data_corr_ae.h5py' # wiki_deep_doc2vec_data
        valid_len = 231
        MAP = -1
    elif data_name == 'nus_wide_doc2vec':
        path = '../data/NUS-WIDE/nus_wide_deep_doc2vec_data_42941.h5py' # pascal_sentence_deep_doc2vec_data
        valid_len = 5000
        MAP = -1
    elif data_name == 'xmedianet_doc2vec':
        path = '../data/XMediaNet/xmedianet_deep_doc2vec_data.h5py' #
        valid_len = 4000
        MAP = -1

    if few_labels is True:
        k = ratio
        dataset = data_name_old + '_K=' + str(k) + '.mat'
        # # dataset = data_name_old + '_K=' + str(k) + '.mat'
        data = sio.loadmat('./data/' + dataset)

        # dataset = data_name_old + '_K=' + str(k)
        # data = sio.loadmat('../NIPS/datasets/' + dataset)


        tr_img = data['tr_img'].astype('float32')
        tr_img = tr_img.reshape([tr_img.shape[0], -1])
        tr_txt = data['tr_txt'].astype('float32')
        tr_txt = tr_txt.reshape([tr_txt.shape[0], -1])
        tr_img_labels = data['tr_img_labels'].reshape([-1]).astype('int64')
        tr_txt_labels = data['tr_txt_labels'].reshape([-1]).astype('int64')

        tr_labeled_img = tr_img[tr_img_labels >= 0]
        tr_labeled_txt = tr_txt[tr_txt_labels >= 0]
        tr_labeled_img_labels = tr_img_labels[tr_img_labels >= 0]
        tr_labeled_txt_labels = tr_txt_labels[tr_txt_labels >= 0]

        tr_unlabeled_img = tr_img[tr_img_labels < 0]
        tr_unlabeled_txt = tr_txt[tr_txt_labels < 0]
        tr_unlabeled_img_labels = tr_img_labels[tr_img_labels < 0]
        tr_unlabeled_txt_labels = tr_txt_labels[tr_txt_labels < 0]

        val_img = data['val_img'].astype('float32')
        val_img = val_img.reshape([val_img.shape[0], -1])
        val_txt = data['val_txt'].astype('float32')
        val_txt = val_txt.reshape([val_txt.shape[0], -1])
        val_img_labels = data['val_img_labels'].reshape([-1]).astype('int64')
        val_txt_labels = data['val_txt_labels'].reshape([-1]).astype('int64')
        te_img = data['te_img'].astype('float32')
        te_img = te_img.reshape([te_img.shape[0], -1])
        te_txt = data['te_txt'].astype('float32')
        te_txt = te_txt.reshape([te_txt.shape[0], -1])
        te_img_labels = data['te_img_labels'].reshape([-1]).astype('int64')
        te_txt_labels = data['te_txt_labels'].reshape([-1]).astype('int64')

        return [tr_labeled_img, tr_labeled_txt], [tr_labeled_img_labels, tr_labeled_txt_labels], [tr_unlabeled_img, tr_unlabeled_txt], [tr_unlabeled_img_labels, tr_unlabeled_txt_labels], [val_img, val_txt], [val_img_labels, val_txt_labels], [te_img, te_txt], [te_img_labels, te_txt_labels], MAP
    else:
        h = h5py.File(path)
        train_imgs_deep = h['train_imgs_deep'][()].astype('float32')
        train_imgs_labels = h['train_imgs_labels'][()]
        train_imgs_labels -= np.min(train_imgs_labels)
        try:
            train_texts_idx = h['train_text'][()].astype('float32')
        except Exception as e:
            train_texts_idx = h['train_texts'][()].astype('float32')
        train_texts_labels = h['train_texts_labels'][()]
        train_texts_labels -= np.min(train_texts_labels)
        train_data = [train_imgs_deep, train_texts_idx]
        train_labels = [train_imgs_labels, train_texts_labels]

        # valid_data = False

        test_imgs_deep = h['test_imgs_deep'][()].astype('float32')
        test_imgs_labels = h['test_imgs_labels'][()]
        test_imgs_labels -= np.min(test_imgs_labels)
        try:
            test_texts_idx = h['test_text'][()].astype('float32')
        except Exception as e:
            test_texts_idx = h['test_texts'][()].astype('float32')
        test_texts_labels = h['test_texts_labels'][()]
        test_texts_labels -= np.min(test_texts_labels)
        test_data = [test_imgs_deep, test_texts_idx]
        test_labels = [test_imgs_labels, test_texts_labels]

        valid_flag = True
        try:
            valid_texts_idx = h['valid_text'][()].astype('float32')
        except Exception as e:
            try:
                valid_texts_idx = h['valid_texts'][()].astype('float32')
            except Exception as e:
                valid_flag = False
                valid_data = [test_data[0][0: valid_len], test_data[1][0: valid_len]]
                valid_labels = [test_labels[0][0: valid_len], test_labels[1][0: valid_len]]

                test_data = [test_data[0][valid_len::], test_data[1][valid_len::]]
                test_labels = [test_labels[0][valid_len::], test_labels[1][valid_len::]]
        if valid_flag:
            valid_imgs_deep = h['valid_imgs_deep'][()].astype('float32')
            valid_imgs_labels = h['valid_imgs_labels'][()]
            valid_texts_labels = h['valid_texts_labels'][()]
            valid_texts_labels -= np.min(valid_texts_labels)
            valid_data = [valid_imgs_deep, valid_texts_idx]
            valid_labels = [valid_imgs_labels, valid_texts_labels]

        if len(train_labels[0].shape) == 1 or train_labels[0].shape[1] == 1:
            classes = np.unique(train_labels[0])
            k = int(train_labels[0].shape[0] * ratio / classes.shape[0])
        else:
            k = int(train_labels[0].shape[0] * ratio)
        # if len(train_labels[0].shape) == 1 or train_labels[0].shape[0] == 1 or train_labels[0].shape[1] == 1:
        n_view = len(train_data)
        valid_flag = True
        if not valid_data:
            valid_data = [0 for i in range(n_view)]
            valid_labels = [0 for i in range(n_view)]
            valid_flag = False
        train_labelled_data = [0 for i in range(n_view)]
        train_labelled_labels = [0 for i in range(n_view)]
        train_unlabelled_data = [0 for i in range(n_view)]
        train_unlabelled_labels = [0 for i in range(n_view)]
        for v in range(n_view):
            # train_seen_inx = (classes == train_labels[v].reshape([-1, 1])).sum(1).nonzero()
            if len(train_labels[0].shape) == 1 or train_labels[0].shape[1] == 1:
                train_seen_inx = []
                train_unseen_inx = []
                for i in range(len(classes)):
                    c = classes[i]
                    inx = (c == train_labels[v].reshape([-1])).nonzero()[0]
                    np.random.shuffle(inx)
                    train_seen_inx.append(inx[0: k])
                    train_unseen_inx.append(inx[k::])
                train_seen_inx = np.concatenate(train_seen_inx)
                train_unseen_inx = np.concatenate(train_unseen_inx)
            else:
                train_seen_inx = np.arange(k)
                train_unseen_inx = np.arange(k, train_labels[v].shape[0])


            train_labelled_data[v] = train_data[v][train_seen_inx]
            train_labelled_labels[v] = train_labels[v][train_seen_inx]

            train_unlabelled_data[v] = train_data[v][train_unseen_inx]
            train_unlabelled_labels[v] = train_labels[v][train_unseen_inx] * 0 - 1

        sio.savemat('./data/' + data_name_old + '_K=' + str(k) + '.mat', {'tr_img': np.concatenate([train_labelled_data[0], train_unlabelled_data[0]]), 'tr_txt': np.concatenate([train_labelled_data[1], train_unlabelled_data[1]]), 'tr_img_labels': np.concatenate([train_labelled_labels[0], train_unlabelled_labels[0]]), 'tr_txt_labels': np.concatenate([train_labelled_labels[1], train_unlabelled_labels[1]]), 'val_img': valid_data[0], 'val_txt': valid_data[1], 'val_img_labels': valid_labels[0], 'val_txt_labels': valid_labels[1], 'te_img': test_data[0], 'te_txt': test_data[1], 'te_img_labels': test_labels[0], 'te_txt_labels': test_labels[1]})
        return train_labelled_data, train_labelled_labels, train_unlabelled_data, train_unlabelled_labels, valid_data, valid_labels, test_data, test_labels, -1
