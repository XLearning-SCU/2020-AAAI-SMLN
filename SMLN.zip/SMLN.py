import torch
import numpy as np

from torch import optim
import utils
import torch.nn.functional as F
import data_loader
from torch.autograd import Variable
import scipy.io as sio
import sklearn.metrics.pairwise as smp


class Solver(object):
    def __init__(self, config, svhn_loader, mnist_loader):
        self.svhn_loader = svhn_loader
        self.mnist_loader = mnist_loader
        wv_matrix = None

        self.output_shape = config.output_shape
        data = data_loader.load_deep_features(config.datasets, config.K)
        self.KNN = config.KNN
        self.datasets = config.datasets
        (self.train_data, self.train_labels, self.train_unseen_data, self.train_unseen_labels, self.valid_data, self.valid_labels, self.test_data, self.test_labels, self.MAP) = data
        self.text_views = [-1]
        self.n_view = len(self.train_data)

        if len(self.train_labels[0].shape) == 1:
            self.classes = np.unique(np.concatenate(self.train_labels).reshape([-1]))
            self.classes = self.classes[self.classes >= 0]
            self.num_classes = len(self.classes)
        else:
            self.num_classes = self.train_labels[0].shape[1]

        if self.output_shape == -1:
            self.output_shape = self.num_classes

        self.all = config.all
        self.train_seen_data = [self.train_data[v] for v in range(self.n_view)]
        self.train_seen_labels = [self.train_labels[v] for v in range(self.n_view)]
        if self.all:
            for v in range(len(self.train_data)):
                if self.train_unseen_data[v].shape[0] == 0:
                    self.train_data[v] = np.concatenate([self.train_data[v], self.train_data[v]], axis=0)
                    self.train_labels[v] = np.concatenate([self.train_labels[v], np.ones_like(self.train_labels[v]) * -1], axis=0)
                else:
                    self.train_data[v] = np.concatenate([self.train_data[v], self.train_unseen_data[v]], axis=0)
                    self.train_labels[v] = np.concatenate([self.train_labels[v], np.ones_like(self.train_unseen_labels[v]) * -1], axis=0)

        self.train_data = [self.train_data[i].reshape([self.train_data[i].shape[0], -1]) for i in range(self.n_view)]
        self.train_unseen_data = [self.train_unseen_data[i].reshape([self.train_unseen_data[i].shape[0], -1]) for i in range(self.n_view)]
        self.valid_data = [self.valid_data[i].reshape([self.valid_data[i].shape[0], -1]) for i in range(self.n_view)]
        self.test_data = [self.test_data[i].reshape([self.test_data[i].shape[0], -1]) for i in range(self.n_view)]

        max_value = [self.train_data[i].max() for i in range(self.n_view)]
        # FC
        self.train_data = [self.train_data[i] / max_value[i] for i in range(self.n_view)]
        self.train_unseen_data = [self.train_unseen_data[i] / max_value[i] for i in range(self.n_view)]
        self.valid_data = [self.valid_data[i] / max_value[i] for i in range(self.n_view)]
        self.test_data = [self.test_data[i] / max_value[i] for i in range(self.n_view)]

        self.word_dim = 300
        self.dropout_prob = 0.5
        if wv_matrix is not None:
            self.vocab_size = wv_matrix.shape[0] - 2

        self.filters = [3, 4, 5]
        self.filter_num = [100, 100, 100]

        self.input_shape = [self.train_data[v].shape[1] for v in range(self.n_view)]

        self.lr = config.lr
        self.beta1 = config.beta1
        self.beta2 = config.beta2
        self.batch_size = config.batch_size

        self.epochs = config.epochs
        self.sample_interval = config.sample_interval

        self.just_valid = config.just_valid

        if self.batch_size < 0:
            self.batch_size = 100 if self.num_classes < 100 else 500

    def to_var(self, x):
        """Converts numpy to variable."""
        if type(x) is np.ndarray:
            x = torch.tensor(x)
        if torch.cuda.is_available():
            x = x.cuda()
        return Variable(x) #torch.autograd.Variable

    def to_data(self, x):
        """Converts variable to numpy."""
        try:
            if torch.cuda.is_available():
                x = x.cpu()
            return x.data.numpy()
        except Exception as e:
            return x

    def to_one_hot(self, x):
        if len(x.shape) == 1 or x.shape[1] == 1:
            one_hot = (self.classes.reshape([1, -1]) == x.reshape([-1, 1])).astype('float32')
            labels = one_hot
            y = self.to_var(torch.tensor(labels))
        else:
            y = self.to_var(torch.tensor(x.astype('float32')))
        return y

    def view_result(self, _acc):
        res = ''
        if type(_acc) is not list:
            res += ((' - mean: %.5f' % (np.sum(_acc) / (self.n_view * (self.n_view - 1)))) + ' - detail:')
            for _i in range(self.n_view):
                for _j in range(self.n_view):
                    if _i != _j:
                        res += ('%.5f' % _acc[_i, _j]) + ','
        else:
            R = [50, 'ALL']
            for _k in range(len(_acc)):
                res += (' R = ' + str(R[_k]) + ': ')
                res += ((' - mean: %.5f' % (np.sum(_acc[_k]) / (self.n_view * (self.n_view - 1)))) + ' - detail:')
                for _i in range(self.n_view):
                    for _j in range(self.n_view):
                        if _i != _j:
                            res += ('%.5f' % _acc[_k][_i, _j]) + ','
        return res

    def train(self):
        seed = 0
        import numpy as np
        np.random.seed(seed)
        import random as rn
        rn.seed(seed)
        # os.environ['CUDA_VISIBLE_DEVICES'] = '1'
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


        from model import Dense_Net
        get_grad_params = lambda model: [x for x in model.parameters() if x.requires_grad]
        Nets, params = [], []
        for view_id in range(self.n_view):
            Net = Dense_Net(input_dim=self.input_shape[view_id], out_dim=self.output_shape)
            if torch.cuda.is_available():
                Net.cuda()
            Nets.append(Net)
            params += get_grad_params(Net)
        optimizer = optim.Adam(params, self.lr, [self.beta1, self.beta2], weight_decay=0)

        discriminator_losses, losses, valid_results = [], [], []
        valid_res_max = 0
        eigvals_list, all_acc = [], []
        for epoch in range(self.epochs):
            print(('Epoch %d/%d') % (epoch + 1, self.epochs))

            rand_idx_list = []
            rand_idx = np.arange(self.train_data[0].shape[0])
            np.random.shuffle(rand_idx)
            for i in range(self.n_view):
                rand_idx_list.append(rand_idx)
            batch_count = int(np.ceil(self.train_data[view_id].shape[0] / float(self.batch_size)))

            k = 0
            mean_loss = []
            mean_tr_ae_loss = []
            epoch_eigenvals = 0
            for batch_idx in range(batch_count):
                train_x, train_y, view_y, view_y_fake, train_dist_map = [], [], [], [], []
                for i in range(self.n_view):
                    idx = rand_idx_list[i][batch_idx * self.batch_size: (batch_idx + 1) * self.batch_size]
                    data = self.train_data[i][idx]
                    train_x.append(self.to_var(torch.tensor(data)))
                    if len(self.train_labels[i].shape) == 1 or self.train_labels[i].shape[1] == 1:
                        one_hot = (self.train_labels[i][idx].reshape([-1, 1]) == self.classes.reshape([1, -1])).astype('float32')
                        train_y.append(self.to_var(one_hot))
                    else:
                        train_y.append(self.to_var(self.train_labels[i][idx].astype('float32')))

                    if i in self.text_views:
                        tmp = []
                        for k in range(data.shape[0]):
                            tt = self.wv_matrix[data[k]]
                            tt = tt[np.abs(tt).sum(1).nonzero()].mean(0).reshape([1, -1])
                            tmp.append(tt)
                        data = np.concatenate(tmp, axis=0)
                    dist_tmp = smp.pairwise_distances(data.reshape([data.shape[0], -1]))
                    dist_tmp = (dist_tmp / dist_tmp[np.nonzero(dist_tmp)].min() * 2.) ** 2
                    dist_tmp = np.exp(-dist_tmp)
                    train_dist_map.append(self.to_var(dist_tmp.astype('float32')))

                optimizer.zero_grad()
                out = []
                for view_id in range(self.n_view):
                    out.append(Nets[view_id](train_x[view_id])[-1].view([train_x[view_id].shape[0], -1]))
                loss, eigvals = utils.SMLN_loss(out, train_dist_map, train_y, self.KNN)
                loss.backward()
                optimizer.step()

                mean_loss.append(self.to_data(loss))
                epoch_eigenvals = epoch_eigenvals + eigvals

                if ((epoch + 1) % self.sample_interval == 0) and (batch_idx == batch_count - 1):
                    eigvals_list.append(self.to_data(epoch_eigenvals / batch_count))
                    losses.append(np.mean(mean_loss))

                    train_unseen_tmp, test_tmp = [], []
                    for view_id in range(self.n_view):
                        # test_tmp.append(utils.predict(lambda x: Nets[view_id](x)[-1].view([x.shape[0], -1]), self.valid_data[view_id], self.batch_size).reshape([self.valid_data[view_id].shape[0], -1]))
                        test_tmp.append(utils.predict(lambda x: Nets[view_id](x)[-1].view([x.shape[0], -1]), self.test_data[view_id], self.batch_size).reshape([self.test_data[view_id].shape[0], -1]))
                    test_results = utils.multi_test(test_tmp, self.test_labels, self.MAP)
                    all_acc.append(test_results)
                    if np.sum(valid_res_max) < np.sum(test_results[1] if type(test_results) is list else  test_results) and not self.just_valid:
                        valid_res_max = test_results[1] if type(test_results) is list else  test_results
                        test_pre = [utils.predict(lambda x: Nets[v](x)[-1].view([x.shape[0], -1]), self.test_data[v], self.batch_size).reshape([self.test_data[v].shape[0], -1]) for v in range(self.n_view)]
                        best_epoch = epoch
                        utils.show_progressbar([batch_idx, batch_count], mean_loss=np.mean(mean_loss), best_resutls=self.view_result(valid_res_max))

                    elif self.just_valid:
                        utils.show_progressbar([batch_idx, batch_count], mean_loss=np.mean(mean_loss))
                    else:
                        utils.show_progressbar([batch_idx, batch_count], mean_loss=np.mean(mean_loss))

                elif batch_idx == batch_count - 1:
                    utils.show_progressbar([batch_idx, batch_count], mean_loss=np.mean(mean_loss))
                    losses.append(np.mean(mean_loss))
                else:
                    utils.show_progressbar([batch_idx, batch_count], loss=loss)
                k += 1

        if not self.just_valid:
            test = test_pre
            test_results = utils.multi_test(test, self.test_labels, self.MAP)
            print("best_epoch: " + str(best_epoch) + ",\t test resutls:" + self.view_result(test_results))
            sio.savemat('features/' + self.datasets + '_test_feature_results.mat', {'test': test, 'test_labels': self.test_labels})
            return valid_results, test_results
        else:
            sio.savemat('features/' + self.datasets + '_loss' + '_' + str(self.all) + '.mat', {'loss': np.array(losses)})
            return np.array(losses)
