
def str2bool(v):
    return v.lower() in ('true')


def main(config):
    svhn_loader, mnist_loader = None, None
    from SMLN import Solver
    solver = Solver(config, svhn_loader, mnist_loader)
    cudnn.benchmark = True

    if config.mode == 'train':
        return solver.train()

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()

    parser.add_argument('--beta1', type=float, default=0.5)
    parser.add_argument('--beta2', type=float, default=0.999)

    # misc
    parser.add_argument('--mode', type=str, default='train')
    parser.add_argument('--just_valid', type=bool, default=False)

    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--lr', type=list, default=1e-4)
    parser.add_argument('--output_shape', type=int, default=-1)
    parser.add_argument('--datasets', type=str, default='wiki_doc2vec_few_labels') # wiki_doc2vec, nus_wide_doc2vec, xmedianet_doc2vec
    parser.add_argument('--sample_interval', type=int, default=1)
    parser.add_argument('--epochs', type=int, default=200) # XMediaNet: 50
    parser.add_argument('--all', type=bool, default=True)
    parser.add_argument('--K', type=int, default=0.3)
    parser.add_argument('--KNN', type=int, default=2)
    config = parser.parse_args()
    # ratio = [0.05, 0.1, 0.3]
    ratio = [0.3]
    # ratio = [400]
    all_results = []
    for i in range(len(ratio)):
        config = parser.parse_args()
        config.K = ratio[i]
        import numpy as np
        from torch.backends import cudnn
        cudnn.enabled = False

        print(config)

        valid_results, test_results = main(config)
        all_results.append(test_results)

    print(all_results)
    for i in range(len(ratio)):
        print('K = %g' % ratio[i])
        print('%.3f\t%.3f\t%.3f' % (all_results[i][1][0, 1], all_results[i][1][1, 0], (all_results[i][1][0, 1] + all_results[i][1][1, 0]) / 2.))
