import torch
import numpy as np
import sys
import scipy.linalg as sli
import torch.nn.functional as F
import torch.nn as nn
from torch import optim
import math


def to_tensor(x):
    if type(x) is not torch.Tensor:
        x = torch.tensor(x)
    if torch.cuda.is_available():
        x = x.cuda()
    return x

def to_data(x):
    if type(x) is torch.Tensor:
        if torch.cuda.is_available():
            x = x.cpu()
        return x.numpy()
    else:
        return x

def SMLN_loss(data, sim_map, label, K):
    n_view = len(data)
    Ws, cols = [], []
    row = torch.arange(sim_map[0].shape[0]).long().view([-1, 1]).repeat([1, K + 1])
    for v in range(n_view):
        _, col = sim_map[v].sort(descending=True)
        col = col[:, 0: K + 1]
        Wtmp = to_tensor(torch.zeros(sim_map[v].shape[0], sim_map[v].shape[0]).float())
        Wtmp[row, col] = sim_map[v][row, col]
        Wtmp[col, row] = sim_map[v][col, row]
        Ws.append(Wtmp)
        cols.append(col)
    W = []
    for i in range(n_view):
        tmp = []
        for j in range(n_view):
            s_map_ij = (Ws[i] + Ws[j]) / 2.
            s_map_ij[label[i].mm(label[j].t()) > 0] = 1.
            tmp.append(s_map_ij)
        W.append(torch.cat(tmp, dim=1))
    W = torch.cat(W, dim=0)
    D = W.sum(1).diag()
    data = torch.cat(data, dim=0)
    L = D - W
    L = data.t().mm(L).mm(data)
    D = data.t().mm(D).mm(data)
    top_k_evals = eigh.apply(D, L)
    scale = top_k_evals[top_k_evals > 0].min().ceil()
    costs = (-(top_k_evals / scale)).exp().mean()

    return costs, top_k_evals

def multi_test(data, data_labels, MAP=None, metric='cosine'):
    n_view = len(data)
    res = np.zeros([n_view, n_view])
    if MAP is None:
        for i in range(n_view):
            for j in range(n_view):
                if i == j:
                    continue
                else:
                    from sklearn.neighbors import KNeighborsClassifier
                    neigh = KNeighborsClassifier(n_neighbors=1, metric=metric)
                    neigh.fit(data[j], data_labels[j])
                    la = neigh.predict(data[i])
                    res[i, j] = np.sum((la == data_labels[i].reshape([-1])).astype(int)) / float(la.shape[0])
    else:
        if MAP == -1:
            res = [np.zeros([n_view, n_view]), np.zeros([n_view, n_view])]
        for i in range(n_view):
            for j in range(n_view):
                if i == j:
                    continue
                else:
                    if len(data_labels[j].shape) == 1:
                        tmp = fx_calc_map_label(data[j], data_labels[j], data[i], data_labels[i], -1, metric=metric)
                    else:
                        Ks = [50, 0] if MAP == -1 else [MAP]
                        tmp = []
                        for k in Ks:
                            tmp.append(fx_calc_map_multilabel_k(data[j], data_labels[j], data[i], data_labels[i], k=k, metric=metric))
                    if type(tmp) is list:
                        for _i in range(len(tmp)):
                            res[_i][i, j] = tmp[_i]
                    else:
                        res[i, j] = tmp
    return res


import scipy
def fx_calc_map_label(train, train_labels, test, test_label, k=0, metric='cosine'):
    dist = scipy.spatial.distance.cdist(test, train, metric)

    ord = dist.argsort(1)

    # numcases = dist.shape[1]
    numcases = train_labels.shape[0]
    if k == 0:
        k = numcases
    if k == -1:
        ks = [50, numcases]
    else:
        ks = [k]

    def calMAP(_k):
        _res = []
        for i in range(len(test_label)):
            order = ord[i]
            p = 0.0
            r = 0.0
            for j in range(_k):
                if test_label[i] == train_labels[order[j]]:
                    r += 1
                    p += (r / (j + 1))
            if r > 0:
                _res += [p / r]
            else:
                _res += [0]
        return np.mean(_res)

    res = []
    for k in ks:
        res.append(calMAP(k))
    return res if len(res) > 1 else res[0]

def fx_calc_map_multilabel_k(train, train_labels, test, test_label, k=0, metric='cosine'):
    dist = scipy.spatial.distance.cdist(test, train, metric)
    ord = dist.argsort()
    numcases = dist.shape[0]
    if k == 0:
        k = numcases
    res = []
    for i in range(numcases):
        order = ord[i].reshape(-1)[0: k]

        tmp_label = (np.dot(train_labels[order], test_label[i]) > 0)
        if tmp_label.sum() > 0:
            prec = tmp_label.cumsum() / np.arange(1.0, 1 + tmp_label.shape[0])
            total_pos = float(tmp_label.sum())
            if total_pos > 0:
                res += [np.dot(tmp_label, prec) / total_pos]
    return np.mean(res)

def predict(model, data, batch_size=32, isLong=False):
    batch_count = int(np.ceil(data.shape[0] / float(batch_size)))
    results = []
    with torch.no_grad():
        for i in range(batch_count):
            batch = to_tensor(data[i * batch_size: (i + 1) * batch_size])
            batch = batch.long() if isLong else batch
            results.append(to_data(model(batch)))
            # results.append(to_data(model(batch) > 0.5))
    return np.concatenate(results)

def show_progressbar(rate, *args, **kwargs):
    '''
    :param rate: [current, total]
    :param args: other show
    '''
    inx = rate[0] + 1
    count = rate[1]
    bar_length = 30
    rate[0] = int(np.around(rate[0] * float(bar_length) / rate[1])) if rate[1] > bar_length else rate[0]
    rate[1] = bar_length if rate[1] > bar_length else rate[1]
    num = len(str(count))
    str_show = ('\r%' + str(num) + 'd / ' + '%' + str(num) + 'd  (%' + '3.2f%%) [') % (inx, count, float(inx) / count * 100)
    for i in range(rate[0]):
        str_show += '='

    if rate[0] < rate[1] - 1:
        str_show += '>'

    for i in range(rate[0], rate[1] - 1, 1):
        str_show += '.'
    str_show += '] '
    for l in args:
        str_show += ' ' + str(l)

    for key in kwargs:
        try:
            str_show += ' ' + key + ': %.4f' % kwargs[key]
        except Exception:
            str_show += ' ' + key + ': ' + str(kwargs[key])
    if inx == count:
        str_show += '\n'
    else:
        str_show += '\r'

    sys.stdout.write(str_show)
    sys.stdout.flush()


class eigh(torch.autograd.Function):
    @staticmethod
    def forward(self, Sb, Sw, eigenvectors=False):
        a, b = to_data(Sb), to_data(Sw)
        eta = 0
        for i in range(10):
            try:
                if eta == 0:
                    w, v = sli.eigh(a.astype('float64'), b.astype('float64'))
                else:
                    w, v = sli.eigh(a, b + np.eye(b.shape[0]) * eta)
                w = w.astype('float32')
                v = v.astype('float32')
                if eta != 0:
                    Sw += to_tensor(torch.eye(Sw.shape[0]).float()) * eta
                break
            except:
                eta = pow(10, i - 4)

        # w, v = sli.eigh(a, b)
        # w = w.real.astype('float32')
        # v = v.real.astype('float32')

        w, v = to_tensor(w), to_tensor(v)
        self.save_for_backward(Sb, Sw, w, v)
        if eigenvectors:
            return torch.autograd.Variable(w), torch.autograd.Variable(v)
        else:
            return torch.autograd.Variable(w)

    @staticmethod
    def backward(self, grad_output):
        (Sb, Sw, w, v) = self.saved_tensors
        gA = v.mm(torch.diag(grad_output)).mm(v.transpose(1, 0))
        gB = -v.mm(torch.diag(grad_output * w)).mm(v.transpose(1, 0))

        out1 = gA.tril() + gA.triu(1).transpose(1, 0)
        out2 = gB.tril() + gB.triu(1).transpose(1, 0)
        return out1, out2
