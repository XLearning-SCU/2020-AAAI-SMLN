import torch.nn as nn
import torch.nn.functional as F
import torch

class Dense_Net(nn.Module):
    """Generator for transfering from svhn to mnist"""

    def __init__(self, input_dim=28*28, out_dim=20):
        super(Dense_Net, self).__init__()
        mid_num1, mid_num2 = 4096, 4096
        self.fc1 = nn.Linear(input_dim, mid_num1)
        self.fc2 = nn.Linear(mid_num1, mid_num2)
        self.fc3 = nn.Linear(mid_num2, out_dim)
        # self.dropout = nn.Dropout(0.1)

    def forward(self, x):
        out1 = F.relu(self.fc1(x))
        out2 = F.relu(self.fc2(out1))
        # out2 = self.dropout(out2)
        out3 = self.fc3(out2)
        return [out1, out3]
